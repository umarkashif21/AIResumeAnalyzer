import os
from dotenv import load_dotenv

# Load environment variables from the .env file
dotenv_path = os.path.join(os.path.dirname(__file__), '..', '.env')
load_dotenv(dotenv_path)

def get_env_variable(var_name):
    value = os.getenv(var_name)
    if value is None:
        raise Exception(f"Environment variable {var_name} not set!")
    return value
