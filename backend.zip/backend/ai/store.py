from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from datetime import datetime
from backend.database import feedback_collection
from typing import List

router = APIRouter()

class FeedbackModel(BaseModel):
    user_id: str
    resume_score: float
    ai_suggestions: List[str]

@router.post("/store/")
def store_feedback(feedback: FeedbackModel):
    # Log the payload to the server logs
    print("Received payload:", feedback.dict())
    
    feedback_data = feedback.dict()
    feedback_data["created_at"] = datetime.utcnow()
    result = feedback_collection.insert_one(feedback_data)
    if result.inserted_id:
        return {
            "message": "Feedback stored successfully",
            "feedback_id": str(result.inserted_id)
        }
    raise HTTPException(status_code=500, detail="Failed to store feedback")