import google.generativeai as genai
from backend.config import get_env_variable
import json

# Load API key 
GEMINI_API_KEY = get_env_variable("GEMINI_API_KEY")
genai.configure(api_key=GEMINI_API_KEY)

def generate_suggestions(resume_text: str) -> dict:
    """
    Sends resume text to Gemini API and returns AI-powered suggestions along with a resume score.
    """
    prompt = f"""
    You are an expert career advisor. Analyze the following resume text and provide:
    1. A resume score (out of 100) based on clarity, structure, relevance, and impact.
    2. Constructive feedback on how to improve it, focusing on missing details, formatting, and overall effectiveness.

    Return the response in JSON format:
    {{
      "resume_score": <score>,
      "ai_suggestions": ["Suggestion 1", "Suggestion 2", ...]
    }}

    Resume Text:
    {resume_text}
    """

    try:
        model_name = "models/gemini-1.5-pro-001"  

        # Debugging: Print request details
        print(f"Using Model: {model_name}")
        print(f"Resume Text Length: {len(resume_text)} characters")

        # Initialize model
        model = genai.GenerativeModel(model_name)

        # Generate content
        response = model.generate_content(prompt)

        # Debugging: Print raw response
        print("RAW RESPONSE:", response)

        # Extract response text properly
        if hasattr(response, "text") and response.text:
            ai_output = response.text.strip()
        elif hasattr(response, "candidates") and response.candidates:
            ai_output = response.candidates[0].content.parts[0].text  # Extract structured response
        else:
            return {"resume_score": 0, "ai_suggestions": ["No suggestions available."]}

        # Convert AI output to JSON
        try:
            return json.loads(ai_output)  # AI should return a JSON response
        except json.JSONDecodeError:
            return {"resume_score": 0, "ai_suggestions": ["Error parsing AI response."]}

    except Exception as e:
        print(f"Error: {str(e)}")
        return {"resume_score": 0, "ai_suggestions": [f"Error generating AI suggestions: {str(e)}"]}



