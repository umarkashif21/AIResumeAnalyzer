from fastapi import APIRouter, HTTPException
from fpdf import FPDF
from backend.ai.ai_suggestions import generate_suggestions

router = APIRouter()

@router.post("/resume-feedback/")
def generate_resume_feedback(resume_text: str, filename: str = "resume_feedback.pdf"):
    """
    Generates resume feedback using AI and saves it as a PDF.
    """
    try:
        # Get AI feedback
        ai_response = generate_suggestions(resume_text)
        resume_score = ai_response["resume_score"]
        suggestions = ai_response["ai_suggestions"]

        # Initialize PDF
        pdf = FPDF()
        pdf.set_auto_page_break(auto=True, margin=15)
        pdf.add_page()
        pdf.set_font("Arial", "B", 16)

        # Title
        pdf.cell(200, 10, "Resume Feedback Report", ln=True, align="C")

        # Resume Score
        pdf.set_font("Arial", "B", 12)
        pdf.cell(0, 10, f"Resume Score: {resume_score}%", ln=True)

        # Feedback Section
        pdf.set_font("Arial", "", 11)
        pdf.ln(5)
        pdf.cell(0, 10, "AI Suggestions:", ln=True)
        pdf.ln(5)

        for suggestion in suggestions:
            pdf.multi_cell(0, 8, f"- {suggestion}")

        # Save PDF
        pdf.output(filename)

        return {"message": "PDF generated successfully", "filename": filename}

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate feedback PDF: {str(e)}")
