from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.auth.routes import router as auth_router  
from backend.resume.upload import router as upload_router  
from backend.resume.export_resume import router as export_router  
from backend.ai.resume_feedback import router as pdf_feedback_router  # For generating PDF feedback
from backend.ai.store import router as store_router                   # For storing feedback data
from backend.database import db

app = FastAPI(
    title="AI Resume Analyzer Backend",
    description="Backend API for processing resumes and providing AI-powered insights.",
    version="1.0.0"
)

# CORS Middleware (Adjust in production)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Change this for security in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include authentication routes
app.include_router(auth_router, prefix="/auth", tags=["Authentication"])

# Include resume upload routes
app.include_router(upload_router, prefix="/resume", tags=["Resume Processing"])

# Include export resume report route
app.include_router(export_router, prefix="/export", tags=["Resume Export"])

# Include PDF feedback generation endpoint
app.include_router(pdf_feedback_router, prefix="/ai/resume-feedback", tags=["Resume Feedback PDF"])

# Include feedback storage endpoint (our new store router)
app.include_router(store_router, prefix="/ai", tags=["Feedback Storage"])

# Test MongoDB Connection Route
@app.get("/db-status", tags=["Database"])
def check_db_status():
    try:
        db.command("ping")  # Ping MongoDB
        return {"message": "✅ Connected to MongoDB!"}
    except Exception as e:
        return {"error": str(e)}

# Test Routes
@app.get("/test", tags=["Testing"])
def test_route():
    return {"message": "Test route is working!"}

@app.get("/", tags=["General"])
def home():
    return {"message": "AI Resume Analyzer Backend is Running!"}

# Print all routes on startup (for debugging)
@app.on_event("startup")
async def on_startup():
    routes = [{"path": route.path, "methods": list(route.methods)} for route in app.routes]
    print("\n✅ Registered Routes:")
    for route in routes:
        print(f"➡ {route['path']} | Methods: {', '.join(route['methods'])}")

    print("\nAPI Docs: http://127.0.0.1:8000/docs")
    print("Redoc: http://127.0.0.1:8000/redoc\n")
    print("🚀 MongoDB Connection Verified!")
    print("📄 Resume Feedback PDF Route: http://127.0.0.1:8000/ai/resume-feedback")
    print("📄 Feedback Storage Route: http://127.0.0.1:8000/ai/store")
    print("📄 Resume Export Route: http://127.0.0.1:8000/export/export-report\n")
    
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)