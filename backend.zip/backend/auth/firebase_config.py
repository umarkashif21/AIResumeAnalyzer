import firebase_admin
from firebase_admin import credentials, auth
import os
from dotenv import load_dotenv

# Explicitly load .env from the backend directory
env_path = os.path.join(os.path.dirname(__file__), "../.env")
load_dotenv(env_path)

# Get Firebase credentials path from .env
firebase_credentials_path = os.getenv("FIREBASE_CREDENTIALS")

# Debugging: Print environment path and credentials path
print(f"🔍 Looking for .env at: {env_path}")
print(f"🔍 FIREBASE_CREDENTIALS from .env: {firebase_credentials_path}")

# Check if the path is set correctly
if not firebase_credentials_path:
    raise ValueError("🔥 Firebase credentials path not found. Check your .env file.")

# Convert to absolute path (handles relative paths correctly)
firebase_credentials_path = os.path.abspath(firebase_credentials_path)

# Ensure the file exists at the specified path
if not os.path.exists(firebase_credentials_path):
    raise ValueError(f"🔥 Firebase credentials file not found at: {firebase_credentials_path}")

try:
    # Try to get the existing Firebase app to avoid re-initialization
    firebase_admin.get_app()
    print("✅ Firebase already initialized!")
except ValueError:
    # Firebase is not initialized, so initialize it now
    try:
        cred = credentials.Certificate(firebase_credentials_path)
        firebase_admin.initialize_app(cred)
        print("✅ Firebase initialized successfully!")
    except Exception as e:
        raise ValueError(f"🔥 Firebase initialization failed: {e}")
