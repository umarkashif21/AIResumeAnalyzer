import firebase_admin
from firebase_admin import auth, credentials
import os
from dotenv import load_dotenv
import traceback

# Load environment variables

