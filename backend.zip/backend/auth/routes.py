from fastapi import APIRouter, HTTPException
from firebase_admin import auth, exceptions  # ✅ Import correct exceptions
from .firebase_config import firebase_admin  # Ensure Firebase is initialized
from .models import UserSignup, UserLogin, ForgotPasswordRequest
from backend.database import users_collection  # ✅ Import MongoDB users collection
from datetime import datetime
import logging

# Set up logging configuration
logging.basicConfig(level=logging.DEBUG, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

router = APIRouter()

# 🚀 SIGNUP
@router.post("/signup")
async def signup(user: UserSignup):
    try:
        logger.debug(f"🔍 Checking user: {user.email}")  # Debugging line
        
        # Check if the user already exists
        try:
            auth.get_user_by_email(user.email)
            logger.debug("❌ User already exists!")  # Debugging line
            raise HTTPException(status_code=400, detail="User already exists!")
        except auth.UserNotFoundError:  # ✅ Correct exception
            logger.debug("✅ User does not exist, proceeding with signup.")  # Debugging line

        # 🆕 Create a new Firebase user
        firebase_user = auth.create_user(email=user.email, password=user.password)
        logger.debug(f"✅ Firebase User Created: {firebase_user.uid}")  # Debugging line
        
        # ✅ Store user in MongoDB
        user_data = {
            "email": user.email,
            "uid": firebase_user.uid,
            "created_at": datetime.utcnow()
        }
        users_collection.insert_one(user_data)  # 🔥 Insert into MongoDB
        logger.debug(f"✅ User stored in MongoDB with uid: {firebase_user.uid}")  # Debugging line

        return {"message": "User created successfully", "uid": firebase_user.uid}

    except auth.EmailAlreadyExistsError:
        logger.debug("❌ Email already registered!")  # Debugging line
        raise HTTPException(status_code=400, detail="Email already registered!")

    except exceptions.FirebaseError as e:  # ✅ General Firebase exception
        logger.error(f"🔥 Firebase Error: {e}")  # Debugging line
        raise HTTPException(status_code=500, detail=f"Firebase Error: {e}")

    except Exception as e:
        logger.error(f"🔥 Unexpected Signup Error: {e}")  # Debugging line
        raise HTTPException(status_code=500, detail=f"Unexpected error: {e}")


# 🚀 LOGIN
@router.post("/login")
async def login(user: UserLogin):
    logger.debug(f"🔍 Attempting login for email: {user.email}")  # Debugging line
    try:
        # 🔍 Check if user exists in Firebase
        firebase_user = auth.get_user_by_email(user.email)
        logger.debug(f"✅ User Found in Firebase: {firebase_user.uid}")  # Debugging line

        # 🔍 Check if user exists in MongoDB
        user_data = users_collection.find_one({"uid": firebase_user.uid})
        if not user_data:
            logger.debug(f"❌ User not found in MongoDB for uid: {firebase_user.uid}")  # Debugging line
            raise HTTPException(status_code=400, detail="User not found in MongoDB")

        logger.debug(f"✅ User found in MongoDB, proceeding with login.")  # Debugging line
        return {"message": "Login successful", "uid": firebase_user.uid}
    
    except auth.UserNotFoundError:
        logger.debug("❌ User not found in Firebase!")  # Debugging line
        raise HTTPException(status_code=400, detail="User not found")

    except exceptions.FirebaseError as e:
        logger.error(f"🔥 Firebase Error: {e}")  # Debugging line
        raise HTTPException(status_code=500, detail="Internal server error")

    except Exception as e:
        logger.error(f"🔥 Unexpected Error: {e}")  # Debugging line
        raise HTTPException(status_code=500, detail="Internal server error")


# 🚀 FORGOT PASSWORD
@router.post("/forgot-password")
async def forgot_password(request: ForgotPasswordRequest):
    logger.debug(f"🔍 Checking for user with email: {request.email}")  # Debugging line
    try:
        # 🔍 Check if user exists
        user = auth.get_user_by_email(request.email)
        logger.debug(f"✅ User Found for Reset: {user.uid}")  # Debugging line

        # 📩 Generate password reset link
        reset_link = auth.generate_password_reset_link(request.email)
        logger.debug(f"✅ Reset Link Generated: {reset_link}")  # Debugging line

        return {"message": "Password reset link sent!", "reset_link": reset_link}

    except auth.UserNotFoundError:
        logger.debug("❌ User not found!")  # Debugging line
        raise HTTPException(status_code=400, detail="User not found")

    except exceptions.FirebaseError as e:
        logger.error(f"🔥 Firebase Error: {e}")  # Debugging line
        raise HTTPException(status_code=500, detail="Internal server error")

    except Exception as e:
        logger.error(f"🔥 Unexpected Error: {e}")  # Debugging line
        raise HTTPException(status_code=500, detail="Internal server error")
