from pymongo import MongoClient

# MongoDB Connection URI (Update this if using MongoDB Atlas later)
MONGO_URI = "mongodb://localhost:27017"

# Create a MongoDB Client
client = MongoClient(MONGO_URI)

# Define Database
db = client["resume_analyzer"]

# Define Collections
users_collection    = db["users"]
resumes_collection  = db["resumes"]
feedback_collection = db["feedback"]  # New collection to store resume score and feedback

print("✅ Connected to MongoDB Successfully!")

# Export collections for use in routes
__all__ = ["users_collection", "resumes_collection", "feedback_collection"]