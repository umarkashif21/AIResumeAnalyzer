import os
from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse
from backend.ai.resume_feedback import generate_resume_feedback  # Import PDF generator

router = APIRouter()

# Define the absolute path to store PDFs
PDF_DIR = os.path.abspath(os.getcwd())  # Adjust if needed

@router.get("/export-report/")
async def export_resume_report():
    """
    Generates the resume feedback PDF and returns it as a downloadable file.
    """
    try:
        filename = "resume_feedback.pdf"
        file_path = os.path.join(PDF_DIR, filename)

        # Sample text (Replace with actual extracted resume data)
        resume_text = "Sample resume text for testing"
        
        # Generate the PDF
        generate_resume_feedback(resume_text, file_path)

        # Ensure the file exists before returning it
        if not os.path.exists(file_path):
            raise HTTPException(status_code=500, detail="PDF generation failed.")

        return FileResponse(file_path, media_type="application/pdf", filename=filename)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating PDF: {str(e)}")
