from fastapi import APIRouter, UploadFile, File, HTTPException
import os
from backend.resume.parser import extract_text  # Import parser functions
from backend.ai.ai_suggestions import generate_suggestions
from backend.database import resumes_collection  # MongoDB collection

router = APIRouter()
UPLOAD_DIR = "uploaded_resumes"
os.makedirs(UPLOAD_DIR, exist_ok=True)  # Ensure upload folder exists

# Store resume feedback data (Temporary storage for dashboard)
resume_data = {"resume_score": None, "ai_suggestions": []}

@router.post("/upload/")
async def upload_resume(file: UploadFile = File(...)):
    """Upload, process resume, generate AI feedback, and store in MongoDB."""
    file_ext = file.filename.split(".")[-1].lower()
    if file_ext not in ["pdf", "docx"]:
        raise HTTPException(status_code=400, detail="Only PDF and DOCX files are allowed.")

    file_location = os.path.join(UPLOAD_DIR, file.filename)
    with open(file_location, "wb") as buffer:
        buffer.write(await file.read())

    try:
        extracted_text = extract_text(file_location)  # Extract text from resume
        print(f"Extracted Text (First 500 chars): {extracted_text[:500]}")  # Debugging Log
        
        # Generate AI feedback (suggestions & score)
        ai_feedback = generate_suggestions(extracted_text)
        ai_suggestions = ai_feedback.get("ai_suggestions", "No feedback available.")
        resume_score = ai_feedback.get("resume_score", 0)

        # Store feedback for dashboard (temporary in-memory)
        resume_data["resume_score"] = resume_score
        resume_data["ai_suggestions"] = ai_suggestions

        print(f"Resume Score: {resume_score}")
        print(f"AI Suggestions: {ai_suggestions}")  # Debugging Log

        # Store in MongoDB
        resume_doc = {
            "filename": file.filename,
            "text": extracted_text,
            "resume_score": resume_score,
            "ai_suggestions": ai_suggestions
        }
        inserted = resumes_collection.insert_one(resume_doc)
        print(f"✅ Resume stored in MongoDB with ID: {inserted.inserted_id}")

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing resume: {str(e)}")

    return {
        "filename": file.filename,
        "filepath": file_location,
        "resume_score": resume_score,
        "ai_suggestions": ai_suggestions
    }

@router.get("/resume-feedback/")
async def get_resume_feedback():
    """Returns stored resume feedback for the dashboard."""
    return resume_data
