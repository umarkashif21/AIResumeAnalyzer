# resume/parser_nlp.py

import re
import spacy
from resume.models import ResumeData

# Load spaCy model for NLP processing
nlp = spacy.load("en_core_web_sm")

def extract_name(text: str) -> str:
    """Extracts the first name-like entity from the resume text."""
    lines = text.strip().split("\n")
    if lines:
        return lines[0]  # Assume first line is the name
    return "Not Found"

def extract_email(text: str) -> str:
    """Extracts email using regex."""
    match = re.search(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", text)
    return match.group() if match else "Not Found"

def extract_phone(text: str) -> str:
    """Extracts phone number using regex."""
    match = re.search(r"\(?\+?\d{1,3}?\)?[-.\s]?\d{3}[-.\s]?\d{3,4}[-.\s]?\d{3,4}", text)
    return match.group() if match else "Not Found"

def extract_section(text: str, section_name: str) -> str:
    """Extracts a section based on keywords."""
    pattern = rf"(?i){section_name}.*?:?\n(.*?)(?:\n[A-Z][a-z]+|\Z)"  # Matches section until next title
    match = re.search(pattern, text, re.DOTALL)
    return match.group(1).strip() if match else "Not Found"

def extract_education(text: str) -> str:
    """Extracts education details from the text."""
    return extract_section(text, "Education")

def extract_experience(text: str) -> str:
    """Extracts experience details from the text."""
    return extract_section(text, "Experience|Work History|Professional Experience")

def extract_projects(text: str) -> str:
    """Extracts projects from the resume text."""
    return extract_section(text, "Projects|Personal Projects|Technical Projects")

def extract_skills(text: str) -> list:
    """Extracts skills using NLP & common keywords."""
    skill_keywords = {"python", "java", "sql", "machine learning", "power bi", "excel", "fastapi"}
    doc = nlp(text.lower())
    found_skills = {token.text for token in doc if token.text in skill_keywords}
    return list(found_skills) if found_skills else ["Not Found"]

def parse_resume(text: str, filename: str) -> ResumeData:
    """Parses a resume and extracts structured information."""
    return ResumeData(
        filename=filename,
        text=text,
        parsed_skills=extract_skills(text),
        parsed_experience=[extract_experience(text)],
    )
