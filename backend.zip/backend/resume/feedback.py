from flask import Blueprint, request, jsonify
from datetime import datetime
from database import feedback_collection

feedback_bp = Blueprint("feedback", __name__)

@feedback_bp.route("/resume/feedback/", methods=["POST"])
def create_feedback():
    data = request.get_json()

    if not data:
        return jsonify({"error": "Invalid JSON data."}), 400

    user_id = data.get("user_id")
    resume_score = data.get("resume_score")
    ai_suggestions = data.get("ai_suggestions")  # Expected to be an array

    # Allow empty list for ai_suggestions, but ensure the key exists
    if user_id is None or resume_score is None or ai_suggestions is None:
        return jsonify({
            "error": "Missing required fields. Please provide user_id, resume_score, and ai_suggestions."
        }), 400

    feedback_data = {
        "user_id": user_id,
        "resume_score": resume_score,
        "ai_suggestions": ai_suggestions,  # Stored as an array in MongoDB
        "created_at": datetime.utcnow()   # Timestamp for last updated info
    }

    result = feedback_collection.insert_one(feedback_data)
    if result.inserted_id:
        return jsonify({
            "message": "Feedback stored successfully.",
            "feedback_id": str(result.inserted_id)
        }), 201
    else:
        return jsonify({"error": "Failed to store feedback."}), 500