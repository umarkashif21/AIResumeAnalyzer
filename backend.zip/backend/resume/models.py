# resume/models.py

from pydantic import BaseModel

class ResumeData(BaseModel):
    filename: str
    text: str
    parsed_skills: list[str] = []
    parsed_experience: list[str] = []
