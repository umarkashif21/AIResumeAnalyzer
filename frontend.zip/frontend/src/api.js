import axios from "axios";

const API_URL = "http://127.0.0.1:8000"; // Backend URL

export const signup = async (email, password) => {
    try {
        const response = await axios.post(`${API_URL}/auth/signup`, { email, password });
        return response.data;
    } catch (error) {
        throw error.response?.data || "Signup failed!";
    }
};

export const login = async (email, password) => {
    try {
        const response = await axios.post(`${API_URL}/auth/login`, { email, password });
        return response.data;
    } catch (error) {
        throw error.response?.data || "Login failed!";
    }
};

export const uploadResume = async (file) => {
    const formData = new FormData();
    formData.append("file", file);

    try {
        const response = await axios.post(`${API_URL}/resume/upload`, formData, {
            headers: { "Content-Type": "multipart/form-data" },
        });
        return response.data;
    } catch (error) {
        throw error.response?.data || "Upload failed!";
    }
};
