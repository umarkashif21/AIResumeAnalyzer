import React, { useEffect, useState } from "react";
import { Container, Button, Card, Spinner, Alert } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

const Dashboard = () => {
  const navigate = useNavigate();
  const [resumeScore, setResumeScore] = useState(null);
  const [feedback, setFeedback] = useState([]);
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/"); // Redirect to login if not authenticated
      return;
    }

    const fetchResumeData = async () => {
      try {
        // Updated endpoint to fetch stored resume feedback
        const response = await fetch("http://localhost:8000/resume/resume-feedback/");
        if (!response.ok) throw new Error("Failed to fetch resume data");

        const data = await response.json();
        setResumeScore(data.resume_score ?? "N/A");
        setFeedback(data.ai_suggestions ?? []);
      } catch (err) {
        setError("Error fetching resume data. Please try again later.");
        console.error("Error fetching resume data:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchResumeData();
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/"); // Redirect to login
  };

  const handleExportReport = async () => {
    setExporting(true);
    setError(null);

    try {
      const response = await fetch("http://localhost:8000/export/export-report/");
      if (!response.ok) throw new Error("Failed to download PDF");

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);

      // Create a temporary link element for download
      const link = document.createElement("a");
      link.href = url;
      link.download = "resume_feedback.pdf";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      // Revoke the URL to free up memory
      window.URL.revokeObjectURL(url);
    } catch (err) {
      setError("Error exporting report. Please try again later.");
      console.error("Error exporting report:", err);
    } finally {
      setExporting(false);
    }
  };

  return (
    <Container className="mt-5">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>ResumeAI Analyzer</h2>
        <Button variant="outline-danger" onClick={handleLogout}>
          Logout
        </Button>
      </div>

      {error && <Alert variant="danger">{error}</Alert>}

      {loading ? (
        <div className="text-center">
          <Spinner animation="border" variant="primary" />
          <p>Loading resume analysis...</p>
        </div>
      ) : (
        <>
          <div className="d-flex gap-4">
            <Card className="p-4 flex-grow-1">
              <h4>Resume Score</h4>
              <h2>{resumeScore !== "N/A" ? `${resumeScore}%` : "N/A"}</h2>
              <p>Last updated: March 15, 2025</p>
            </Card>

            <Card className="p-4 flex-grow-1">
              <h4>Recent Feedback</h4>
              {feedback.length > 0 ? (
                <ul>
                  {feedback.map((item, index) => (
                    <li key={index}>{item}</li>
                  ))}
                </ul>
              ) : (
                <p>No feedback available.</p>
              )}
            </Card>
          </div>

          <div className="mt-4 d-flex gap-3">
            <Button onClick={() => navigate("/resume-upload")} variant="primary">
              Upload Resume
            </Button>
            <Button onClick={() => navigate("/ai-suggestions")} variant="secondary">
              View Recommendations
            </Button>
            <Button onClick={handleExportReport} variant="outline-dark" disabled={exporting}>
              {exporting ? <Spinner animation="border" size="sm" /> : "Export Report"}
            </Button>
            <Button onClick={() => navigate("/cvlifecycle")} variant="info">
              CV Lifecycle
            </Button>
          </div>
        </>
      )}
    </Container>
  );
};

export default Dashboard;