import React, { useEffect, useState } from "react";
import { Container, Card, Alert } from "react-bootstrap";
import axios from "axios";

const AISuggestions = () => {
  const [suggestions, setSuggestions] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchSuggestions = async () => {
      try {
        const response = await axios.get("http://127.0.0.1:8000/ai-suggestions");
        setSuggestions(response.data.suggestions);
      } catch (err) {
        setError("Failed to fetch AI suggestions.");
      }
    };
    fetchSuggestions();
  }, []);

  return (
    <Container className="mt-5">
      <h2>AI Resume Suggestions</h2>
      {error && <Alert variant="danger">{error}</Alert>}
      {suggestions.length > 0 ? (
        suggestions.map((suggestion, index) => (
          <Card className="mt-3" key={index}>
            <Card.Body>{suggestion}</Card.Body>
          </Card>
        ))
      ) : (
        <p>No suggestions available yet.</p>
      )}
    </Container>
  );
};

export default AISuggestions;
