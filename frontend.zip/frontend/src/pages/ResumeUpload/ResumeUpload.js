import React, { useState } from "react";
import { Container, Form, Button, Alert, ProgressBar } from "react-bootstrap";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const ResumeUpload = () => {
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [uploadProgress, setUploadProgress] = useState(0);
  const navigate = useNavigate();

  // Retrieve the user ID from localStorage (set during login)
  const currentUserId = localStorage.getItem("userId");

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file) {
      setError("Please select a file to upload.");
      return;
    }

    const formData = new FormData();
    formData.append("file", file);

    try {
      // Upload resume and get the processing result from the backend
      const response = await axios.post(
        "http://127.0.0.1:8000/resume/upload/",
        formData,
        {
          headers: { "Content-Type": "multipart/form-data" },
          onUploadProgress: (progressEvent) => {
            const progress = Math.round(
              (progressEvent.loaded * 100) / progressEvent.total
            );
            setUploadProgress(progress);
          },
        }
      );

      // Assume the API response contains "resume_score" and "ai_suggestions"
      const { resume_score, ai_suggestions } = response.data;

      // Convert resume_score to number and ensure ai_suggestions is an array
      const numericalScore = Number(resume_score);
      const suggestionsArray = Array.isArray(ai_suggestions)
        ? ai_suggestions
        : [];

      console.log("Numerical Resume Score:", numericalScore);
      console.log("AI Suggestions Array:", suggestionsArray);
      
      // Verify currentUserId exists
      if (!currentUserId) {
        throw new Error("User not authenticated.");
      }

      // Post the feedback details to the new store endpoint
      await axios.post("http://127.0.0.1:8000/ai/store/", {
        user_id: currentUserId,
        resume_score: numericalScore,
        ai_suggestions: suggestionsArray,
      });

      // Optionally show a success message and reset progress
      setMessage("Resume uploaded and feedback stored successfully!");
      setError("");
      setUploadProgress(0);

      // Navigate to the Resume Feedback page and pass the feedback data via state
      navigate("/resumefeedback", {
        state: {
          resumeScore: numericalScore,
          aiSuggestions: suggestionsArray,
        },
      });
    } catch (err) {
      console.error("Error during upload or feedback storage:", err);
      setError("Failed to upload resume. Try again.");
      setMessage("");
      setUploadProgress(0);
    }
  };

  const handleDashboardRedirect = () => {
    navigate("/dashboard");
  };

  return (
    <>
      <Button
        variant="link"
        onClick={handleDashboardRedirect}
        className="position-absolute top-0 end-0 m-3"
      >
        Home
      </Button>

      <Container className="d-flex flex-column align-items-center justify-content-center mt-5">
        <h2 className="mb-4">Upload Resume</h2>
        {error && <Alert variant="danger">{error}</Alert>}
        {message && <Alert variant="success">{message}</Alert>}

        <div className="upload-box p-4 d-flex flex-column align-items-center justify-content-center border rounded shadow bg-white">
          <Form.Group controlId="resumeFile" className="text-center">
            <Form.Label className="d-block mb-3">
              Drag & Drop your file here or
            </Form.Label>
            <Button
              variant="primary"
              onClick={() => document.getElementById("fileInput").click()}
            >
              Choose File
            </Button>
            <Form.Control
              type="file"
              id="fileInput"
              accept=".pdf,.doc,.docx"
              onChange={handleFileChange}
              hidden
            />
            {file && <p className="mt-2 text-muted">Selected: {file.name}</p>}
          </Form.Group>
        </div>

        <Button variant="success" onClick={handleUpload} className="mt-3">
          Process Resume
        </Button>

        {uploadProgress > 0 && uploadProgress < 100 && (
          <ProgressBar
            now={uploadProgress}
            label={`${uploadProgress}%`}
            className="mt-3 w-75"
          />
        )}
      </Container>
    </>
  );
};

export default ResumeUpload;