import React, { useState, useEffect } from "react";
import { Container, Row, Col, Card, Button, Spinner, Alert } from "react-bootstrap";
import axios from "axios";

const CYLifecycle = () => {
  const [summary, setSummary] = useState(null);
  const [timeline, setTimeline] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Fetch data from your backend API (update URL as needed)
    axios.get("http://127.0.0.1:8000/cv/lifecycle")
      .then((response) => {
        // Expecting response.data to have: { summary: { totalUploads, currentScore, lastUpdated }, timeline: [ ... ] }
        setSummary(response.data.summary);
        setTimeline(response.data.timeline);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Error fetching CV lifecycle data:", err);
        setError("Failed to load dashboard data.");
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <Container className="mt-5 text-center">
        <Spinner animation="border" variant="primary" />
      </Container>
    );
  }

  if (error) {
    return (
      <Container className="mt-5">
        <Alert variant="danger">{error}</Alert>
      </Container>
    );
  }

  return (
    <Container className="mt-5">
      <h2 className="mb-4 text-center">CY Lifecycle</h2>

      {/* Top Section: Summary Stats */}
      <Row className="mb-4">
        <Col md={4}>
          <Card className="text-center shadow-sm rounded">
            <Card.Body>
              <Card.Title>Total Versions Uploaded</Card.Title>
              <Card.Text style={{ fontSize: "1.5rem", fontWeight: "bold" }}>
                {summary.totalUploads}
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4}>
          <Card className="text-center shadow-sm rounded">
            <Card.Body>
              <Card.Title>Current Score</Card.Title>
              <Card.Text style={{ fontSize: "1.5rem", fontWeight: "bold" }}>
                {summary.currentScore} / 100
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4}>
          <Card className="text-center shadow-sm rounded">
            <Card.Body>
              <Card.Title>Last Updated</Card.Title>
              <Card.Text style={{ fontSize: "1.2rem" }}>
                {new Date(summary.lastUpdated).toLocaleString()}
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      {/* History Section: Resume Upload Timeline */}
      <h4 className="mb-3">Resume Upload History</h4>
      <Row>
        {timeline.map((event) => (
          <Col key={event.id} md={4} className="mb-4">
            <Card 
              className="shadow-sm rounded h-100"
              style={{ transition: "transform 0.2s" }}
              onMouseEnter={(e) => e.currentTarget.style.transform = "scale(1.03)"}
              onMouseLeave={(e) => e.currentTarget.style.transform = "scale(1)"}
            >
              <Card.Body>
                <Card.Title>{event.version}</Card.Title>
                <Card.Subtitle className="mb-2 text-muted">
                  {event.score} / 100
                </Card.Subtitle>
                <Card.Text>
                  <small>{new Date(event.uploadDate).toLocaleString()}</small>
                </Card.Text>
              </Card.Body>
              <Card.Footer className="bg-white border-0">
                <Button variant="outline-primary" size="sm">
                  View Details
                </Button>
              </Card.Footer>
            </Card>
          </Col>
        ))}
      </Row>
    </Container>
  );
};

export default CYLifecycle;