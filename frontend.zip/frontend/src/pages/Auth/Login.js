import React, { useState } from "react";
import { Form, Button, Container, Alert } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import { getAuth, signInWithEmailAndPassword } from "firebase/auth";  // Firebase Authentication
import { initializeApp } from "firebase/app";  // Firebase initialization
import { firebaseConfig } from "../../firebaseconfig";  // Firebase config import

// Initialize Firebase app
initializeApp(firebaseConfig);

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");  // For error messages
  const [loading, setLoading] = useState(false);  // To handle loading state
  const navigate = useNavigate();  // To navigate to another page

  const handleSubmit = async (e) => {
    e.preventDefault();  // Prevent default form submission
    if (!email || !password) {
      setError("Please fill in all fields.");
      return;
    }
    setLoading(true);
    setError("");  // Reset error on form submission

    try {
      const auth = getAuth();  // Get Firebase Auth instance
      const userCredential = await signInWithEmailAndPassword(auth, email, password);  // Firebase login
      const user = userCredential.user;  // Get user data from Firebase
      
      // Store the Firebase user ID in localStorage (for associating user-specific data later)
      localStorage.setItem("userId", user.uid);
      console.log("Logged in user UID:", user.uid);

      // After successful login, send the user's email and password to the backend for server-side validation
      const response = await fetch("http://127.0.0.1:8000/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),  // Send email and password
      });

      const data = await response.json();
      console.log("Backend Response:", data);

      if (!response.ok) throw new Error(data.detail || "Login failed");

      // Store the authentication token in localStorage (if needed for other requests)
      localStorage.setItem("token", data.token);  // Depending on your backend response, update this key if necessary
      navigate("/dashboard");  // Redirect to the dashboard page after successful login
    } catch (err) {
      console.error("Error during login:", err);  // Log the error for debugging
      setError(err.message || "An error occurred during login");  // Show error message
    } finally {
      setLoading(false);  // Reset loading state
    }
  };

  return (
    <Container className="mt-5">
      <h2>Login</h2>
      {error && <Alert variant="danger">{error}</Alert>}
      <Form onSubmit={handleSubmit}>
        <Form.Group controlId="email">
          <Form.Label>Email Address</Form.Label>
          <Form.Control
            type="email"
            placeholder="Enter email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </Form.Group>

        <Form.Group controlId="password">
          <Form.Label>Password</Form.Label>
          <Form.Control
            type="password"
            placeholder="Enter password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </Form.Group>

        <Button variant="primary" type="submit" className="mt-3" disabled={loading}>
          {loading ? "Logging in..." : "Login"}
        </Button>
      </Form>

      <div className="mt-3">
        <Link to="/forgot-password">Forgot Password?</Link>
      </div>
      <div className="mt-2">
        New here? <Link to="/signup">Sign Up</Link>
      </div>
    </Container>
  );
};

export default Login;