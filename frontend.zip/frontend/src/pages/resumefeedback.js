import React from "react";
import { Container, Card, ListGroup, Button } from "react-bootstrap";
import { useLocation, useNavigate } from "react-router-dom";

const ResumeFeedback = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { resumeScore, aiSuggestions } = location.state || {};

  // Handle case when feedback data is missing
  if (!resumeScore || !aiSuggestions) {
    return (
      <Container className="mt-5">
        <h3>No resume feedback available.</h3>
        <Button variant="primary" onClick={() => navigate("/dashboard")}>
          Go to Dashboard
        </Button>
      </Container>
    );
  }

  return (
    <Container className="mt-5">
      <h2 className="mb-4">Resume Feedback</h2>
      <Card className="mb-4">
        <Card.Body>
          <Card.Title>Resume Score</Card.Title>
          <Card.Text>
            Your resume scored <strong>{resumeScore}</strong> out of 100.
          </Card.Text>
        </Card.Body>
      </Card>
      <Card className="mb-4">
        <Card.Body>
          <Card.Title>AI Suggestions</Card.Title>
          <ListGroup variant="flush">
            {aiSuggestions.map((suggestion, index) => (
              <ListGroup.Item key={index}>{suggestion}</ListGroup.Item>
            ))}
          </ListGroup>
        </Card.Body>
      </Card>
      <Button variant="primary" onClick={() => navigate("/dashboard")}>
        Go to Dashboard
      </Button>
    </Container>
  );
};

export default ResumeFeedback;