import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from "./pages/Auth/Login";
import Signup from "./pages/Auth/Signup";
import ForgotPassword from "./pages/Auth/ForgotPassword";
import Dashboard from "./pages/Dashboard/Dashboard";
import ResumeUpload from "./pages/ResumeUpload/ResumeUpload";
import AISuggestions from "./pages/ResumeUpload/AiSuggestions";
import ResumeFeedback from "./pages/resumefeedback";
import CVLifecycle from "./pages/cvlifecycle";
import "bootstrap/dist/css/bootstrap.min.css";

console.log("App.js is rendering...");

const App = () => {
  return (
    <Router>
      <div className="container mt-5">
        <h1 className="text-center">AI Resume Analyzer</h1>
        <Routes>
          {/* Auth Routes */}
          <Route path="/" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />

          {/* Main Dashboard */}
          <Route path="/dashboard" element={<Dashboard />} />

          {/* Resume Upload & AI Suggestions */}
          <Route path="/resume-upload" element={<ResumeUpload />} />
          <Route path="/ai-suggestions" element={<AISuggestions />} />

          {/* Resume Feedback */}
          <Route path="/resumefeedback" element={<ResumeFeedback />} />

          {/* CV Lifecycle */}
          <Route path="/cvlifecycle" element={<CVLifecycle />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;