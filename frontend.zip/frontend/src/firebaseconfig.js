// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getAuth } from "firebase/auth"
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDjFwPH5-P0eRISw69Og0DxV559kIIMqFM",
  authDomain: "resumeanalyze-5326f.firebaseapp.com",
  projectId: "resumeanalyze-5326f",
  storageBucket: "resumeanalyze-5326f.firebasestorage.app",
  messagingSenderId: "911157222381",
  appId: "1:911157222381:web:0cc053827933b8aabf25e4",
  measurementId: "G-GRB7Q79ZDD"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const auth = getAuth(app);

export { auth, getAuth, getAnalytics, firebaseConfig };